package br.edu.ifpb;
import java.nio.file.Paths;



public class Main {

    public static void main(String[] args) {

        Grep grep = new Grep();
        grep.filtrar("19.99", Paths.get(""));
        grep.editarDados("128","Diario de um banana","Desconhecido","Fisico","99.99");
        grep.editarDados("83","Harry Potter","Desconhecido","Fisico","150.99");
        grep.RemoverTodosFormatos("Fisico");

    }
}

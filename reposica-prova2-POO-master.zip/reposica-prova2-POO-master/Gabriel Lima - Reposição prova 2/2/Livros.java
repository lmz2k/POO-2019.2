package br.edu.ifpb;

import java.util.Objects;

public class Livros implements Comparable<Livros>{

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public boolean equals(Object obj) {

        Livros other = (Livros) obj;
        if (this.getId().equals(other.getId())){
            return true;
        }

        if (this == obj) {
            return true;
        }

        if (!(obj instanceof Livros) || obj == null) {
            return false;
        }


        return false;


    }

    @Override
    public int compareTo(Livros b){
        return getId().compareTo(b.getId());
    }



    private String id;
    private String titulo;
    private String autor;
    private String formato;
    private String preco;


    public Livros(String id, String t, String a, String f, String p) {
        this.id = id;
        this.titulo = t;
        this.autor = a;
        this.formato = f;
        this.preco = p;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }










}

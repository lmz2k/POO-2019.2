package br.edu.ifpb;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.List;

public class Grep {


    private Path origem = Paths.get("DIRETORIO RAIZ AQUI");


    public boolean filtrar(String termo, Path pathDestino) {




        Set<Livros> SET = new TreeSet<>();

        try {
            List<String> LN = Files.readAllLines(origem, Charset.defaultCharset());

            for (String line : LN) {

                String[] LINHA_ARQUIVO = line.split(";");
                String id = LINHA_ARQUIVO[0];
                String titulo = LINHA_ARQUIVO[1];
                String autor = LINHA_ARQUIVO[2];
                String formato = LINHA_ARQUIVO[3];
                String preco = LINHA_ARQUIVO[4];
                Livros l = new Livros(id,titulo,autor,formato,preco);
                SET.add(l);

            }
        } catch (IOException e) {
            System.out.println("Error....");
        }

        SET.forEach(livros -> {
            try {
                if (livros.getAutor().contains(termo) || livros.getId().contains(termo) || livros.getTitulo().contains(termo) || livros.getFormato().contains(termo) || livros.getPreco().contains(termo)) {
                    Files.write(pathDestino, Collections.singleton(String.format(livros.getId() + ";" + livros.getTitulo() + ";" + livros.getAutor() + ";" + livros.getFormato() + ";", livros.getPreco())), StandardOpenOption.CREATE, StandardOpenOption.APPEND, StandardOpenOption.WRITE);
                }

            } catch (IOException e) {
                System.out.println("Error....");
            }
        });
        return true;
    }

    public boolean editarDados(String Id, String novoTitulo, String novoAutor, String novoFormato, String novoPreco) {
        Set<Livros> SET = new TreeSet<>();

        try {
            List<String> LN = Files.readAllLines(origem, Charset.defaultCharset());
            for (String line : LN) {
                String[] LINHA_ARQUIVO = line.split(";");
                if (LINHA_ARQUIVO[0].equals(Id)) {
                    Livros l = new Livros(Id, novoTitulo, novoAutor, novoFormato, novoPreco);
                    SET.add(l);
                } else {
                    String id = LINHA_ARQUIVO[0];
                    String titulo = LINHA_ARQUIVO[1];
                    String autor = LINHA_ARQUIVO[2];
                    String formato = LINHA_ARQUIVO[3];
                    String preco = LINHA_ARQUIVO[4];
                    Livros l = new Livros(id,titulo,autor,formato,preco);
                    SET.add(l);
                }
            }
        } catch (IOException e) {
            System.out.println("Error....");
        }
        SET.forEach(livros -> {

            try {
                Files.write(origem, Collections.singleton(String.format(livros.getId() + ";" + livros.getTitulo() + ";" + livros.getAutor() + ";" + livros.getFormato() + ";", livros.getPreco())), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);

            } catch (IOException e) {
                System.out.println("Error....");
            }
        });

        return true;

    }

    public boolean RemoverTodosFormatos(String Formato) {

        Set<Livros> SET = new TreeSet<>();

        try {
            List<String> LN = Files.readAllLines(origem, Charset.defaultCharset());

            for (String line : LN) {

                String[] LINHA_ARQUIVO = line.split(";");

                if (!LINHA_ARQUIVO[3].equals(Formato)) {

                    String id = LINHA_ARQUIVO[0];
                    String titulo = LINHA_ARQUIVO[1];
                    String autor = LINHA_ARQUIVO[2];
                    String formato = LINHA_ARQUIVO[3];
                    String preco = LINHA_ARQUIVO[4];

                    Livros l = new Livros(id,titulo,autor,formato,preco);
                    SET.add(l);

                }
            }
        } catch (IOException e) {
            System.out.println("Error....");
        }

        SET.forEach(LVR -> {
            try {
                Files.write(origem, Collections.singleton(String.format(LVR.getId() + ";" + LVR.getTitulo() + ";" + LVR.getAutor() + ";" + LVR.getFormato() + ";", LVR.getPreco())), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            } catch (IOException e) {
                System.out.println("Error....");
            }

        });
        return true;
    }


    public Map<String, List<String>> agruparLivrosPorFormato() {


        Set<Livros> SET = new TreeSet<>();

        try {
            List<String> LN = Files.readAllLines(origem, Charset.defaultCharset());

            for (String line : LN) {
                String[] LINHA_ARQUIVO = line.split(";");
                String id = LINHA_ARQUIVO[0];
                String titulo = LINHA_ARQUIVO[1];
                String autor = LINHA_ARQUIVO[2];
                String formato = LINHA_ARQUIVO[3];
                String preco = LINHA_ARQUIVO[4];
                Livros l = new Livros(id,titulo,autor,formato,preco);
                SET.add(l);
            }
        } catch (IOException e) {
            System.out.println("Error....");
        }

        Map<String, List<String>> mapa = new HashMap<>();
        for (Livros l: SET
             ) {
            mapa.put(l.getAutor(), Collections.singletonList(l.getTitulo()));
        }
        return mapa;
    }




}







package br.edu.ifpb;

import java.util.LinkedList;
import java.util.List;

public class Banco {
    private List<Conta> listaContas = null;

    // construtor
    Banco()
    {
        listaContas = new LinkedList<>();
    }

    public boolean cadastrarConta( int número, String titular,
                                   double saldoInicial ){
        

        for( Conta c : listaContas )
            if( c.getNúmero() == número )
                return false;


        Conta temp = new Conta( número, titular, saldoInicial );
        return listaContas.add( temp );

    }

    public int quantidadeContas()
    {
        return listaContas.size();
    }

    public Conta buscarConta( int número )
    {
        for( Conta c : listaContas ) {
            if( c.getNúmero() == número )
                return c;

        }
            return null;
    }


}
package br.edu.ifpb;

public class SaldoInsuficienteException extends  Throwable{
    public SaldoInsuficienteException(){
        this("Saldo insuficiente!");
    }
    public  SaldoInsuficienteException(String Message){
        super(Message);
    }
}

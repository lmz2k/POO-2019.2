package br.edu.ifpb;


import org.apache.commons.lang3.StringUtils;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

import java.util.Random;





public class ExibirMenu {
    public static void main( String[] args ) throws EntradaInvalidaException {
        String name;
        Banco bradesco = new Banco();
        boolean exit = false;
        Scanner Choice = new Scanner( System.in );


        do{

            int choice;
            System.out.println("Projeto Banco");
            System.out.println("======================");
            System.out.println("1 - Criar uma conta");
            System.out.println("2 - Depositar");
            System.out.println("3 - Sacar");
            System.out.println("4 - Extrato");
            System.out.println("5 - SaldoAtual");
            System.out.println("6 - Sair");
            System.out.println("Digite uma opção: ");

            choice = Choice.nextInt();
            Choice.nextLine();

            switch (choice){
                case 1:
                    System.out.println("Insira seu nome: ");

                    try{
                        name = Choice.nextLine();
                        if (!StringUtils.isAlphaSpace(name)) throw new EntradaInvalidaException();

                        System.out.println("Insira o numero da conta: ");
                        int number = Choice.nextInt();

                        if (bradesco.buscarConta(number) != null) throw new ContaInvalidaException();


                        bradesco.cadastrarConta(number , name, 500);

                    }catch (EntradaInvalidaException nfe){
                        System.out.println("O nome digitado é invalido, verifique e digite novamente!");
                    }catch (ContaInvalidaException nfe){
                        System.out.println("Vc esta tentando criar uma conta já existente!");
                    }

                    break;


                case 2:
                    try{
                        System.out.println("Insira o numero da conta: ");
                        int number = Choice.nextInt();

                        if (bradesco.buscarConta(number) == null) throw new ContaInvalidaException();

                        System.out.println("Insira o valor para depositar: ");
                        double value = Choice.nextDouble();

                        bradesco.buscarConta(number).depositar(value);

                        System.out.println("Deposito realizado com sucesso!");
                    }catch (ContaInvalidaException nfe){
                        System.out.println("Conta não encontrada no sistema!");
                    }

                    break;
                case 3:


                    try{
                        System.out.println("Insira o numero da conta: ");
                        int number = Choice.nextInt();

                        if (bradesco.buscarConta(number) == null) throw new ContaInvalidaException();

                        System.out.println("Insira o valor para sacar: ");
                        double value = Choice.nextDouble();

                        bradesco.buscarConta(number).sacar(value);

                    }catch (ContaInvalidaException nfe){
                        System.out.println("Conta não encontrada no sistema!");
                    }

                    break;
                case 4:



                    try{
                        System.out.println("Insira o numero da conta: ");
                        int number = Choice.nextInt();

                        if (bradesco.buscarConta(number) == null) throw new ContaInvalidaException();


                        System.out.println(bradesco.buscarConta(number).toString());

                    }catch (ContaInvalidaException nfe){
                        System.out.println("Conta não encontrada no sistema!");
                    }


                    break;
                case 5:


                    try{
                        System.out.println("Insira o numero da conta: ");
                        int number = Choice.nextInt();

                        if (bradesco.buscarConta(number) == null) throw new ContaInvalidaException();


                        System.out.println( "Saldo da conta eh: "+bradesco.buscarConta(number).getSaldo());

                    }catch (ContaInvalidaException nfe){
                        System.out.println("Conta não encontrada no sistema!");
                    }
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    System.out.println("Entre com um dado Valido!");



            }
        }while ( !exit );






    }






}
//
//        try
//        {
//        nome = lerEntrada( "Entre com o nome: ", scanner );
//
//        if ( !StringUtils.isAlphaSpace( nome ) ) throw new NomeInválidoException();
//
//        idade = Byte.parseByte( lerEntrada( "Entre com a idade: ", scanner ) );
//
//        salario = Double.parseDouble( lerEntrada( "Entre com o salário: ", scanner ) );
//
//        scanner.close(); // encerrando o Scanner
//        ok = true; // se chegou até aqui, não houve exceção
//        } catch ( NumberFormatException nfe )
//        {
//        System.out.println( "\t>> Você não está digitando dados numéricos corretamente. Vamos começar novamente." );
//        } catch ( NomeInválidoException nie )
//        {
//        System.out.printf( "\t>> O nome \'%s\' digitado %s\n", nome, "é inválido. Vamos começar novamente." );
//        }
package br.edu.ifpb;

public class Conta
{
    // área de atributos
    private int    número;
    private String titular;
    private double saldo;

    // construtores
    public Conta(){
        setNúmero( 0 );
        setTitular( "---sem nome---" );

    }

    public Conta( int número, String titular, double saldoInicial ){
        setNúmero( número );
        setTitular( titular );
        depositar( saldoInicial );
    }


    public void sacar( double umaQuantia ){
        try {

            if(umaQuantia <= 0) throw new QuantiaNegativaException();
            if (umaQuantia > this.saldo) throw new SaldoInsuficienteException();

            this.saldo -= umaQuantia;
            System.out.println("Saque realizado com sucesso");

        }catch (QuantiaNegativaException nfe ){
            System.out.println("Tente sacar um valor Maior que 0!");
        }
        catch (SaldoInsuficienteException nfe){
            System.out.println("Você não possui saldo para sacar Este Valor");

        }



    }


    public void depositar( double umaQuantia ){

        try{
            if( umaQuantia <= 0 ) throw new QuantiaNegativaException();

            this.saldo += umaQuantia;


        }catch (QuantiaNegativaException nfe){
            System.out.println("Verifique o valor que esta tentando depositar!");

        }


    }



    public void setNúmero( int umNúmero ){
        if ( umNúmero > 0 )
            número = umNúmero;
    }


    public int getNúmero() {  return número;  }

    public void setTitular( String umTitular )
    {
        if( umTitular != null && umTitular.length() > 0 )
            this.titular = umTitular;
    }

    public String getTitular()
    {
        return titular;
    }

    public double getSaldo() { return saldo; }

    @Override
    public String toString()
    {
        return "Conta: " + this.getNúmero() +
                "; Titular: " + this.getTitular() +
                "; R$ " +  this.getSaldo();
    }
}

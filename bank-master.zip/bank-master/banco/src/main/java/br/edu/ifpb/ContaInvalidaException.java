package br.edu.ifpb;

public class ContaInvalidaException extends  Throwable{

    public ContaInvalidaException(){
        this("Conta Invalida!");
    }

    public ContaInvalidaException(String mensage){
        super(mensage);
    }



}

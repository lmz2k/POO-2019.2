package br.edu.ifpb;

public class QuantiaNegativaException extends Throwable{

    public QuantiaNegativaException(){
        this("Valor negativo!");
    }
    public  QuantiaNegativaException(String mensagem){
        super(mensagem);
    }
}

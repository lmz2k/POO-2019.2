package br.edu.ifpb;

public class EntradaInvalidaException extends Throwable {

    public EntradaInvalidaException ()
    {
        this( "O nome é inválido" );
    }

    public EntradaInvalidaException ( String message )
    {
        super(message);
    }

}

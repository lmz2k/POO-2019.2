package br.edu.ifpb;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class JogoPalavrasCruzadas {

    Set<String> setDePalavras = new TreeSet<>();
    Map<String,Integer> mapaPalavras = new HashMap<String, Integer>();


    JogoPalavrasCruzadas(Path pathOrigem){

        this.setDePalavras = lerPalavrasDoArquivo(pathOrigem);
        this.mapaPalavras = mapaPontosPalavra();

        System.out.println(this.setDePalavras.size());
        System.out.println(this.mapaPalavras.size());

    }


    public Set<String> lerPalavrasDoArquivo(Path pathOrigem){

        Set<String> setAux = new TreeSet<>();

        try(FileReader fr = new FileReader(String.valueOf(pathOrigem));
            BufferedReader br = new BufferedReader( fr );) {

            String linha;
            while ( ( linha = br.readLine() ) != null )
            {
                setAux.add(linha);
            }

        } catch ( FileNotFoundException e ) {
            System.out.println( "Erro: arquivo não existe." );
        }catch (IOException e) {
            System.out.println( "Erro na varredura do arquivo." );
        }


        return setAux;


    }


    public int getPontosdePalavra(String Palavra){

        return this.mapaPalavras.get(Palavra);


    }

    public String getMelhorPalavra(){


        int max = Collections.max(this.mapaPalavras.values());

        for (Map.Entry<String, Integer> entry : this.mapaPalavras.entrySet()) {
            if (entry.getValue()== max) {
                return entry.getKey();
            }
        }

        return null;
    }

    public Set<String> getPalavrasPorFaixaPontos(int inicio, int fim){

        Set<String> palavrasNaFaixa = new TreeSet<String>();

         for(Map.Entry<String, Integer> entry : this.mapaPalavras.entrySet()) {
            if (entry.getValue() >= inicio && entry.getValue() <= fim){
                palavrasNaFaixa.add(entry.getKey());
            }
        }

         return palavrasNaFaixa;
    }

    public Map<String,Integer> mapaPontosPalavra(){

        Map<String,Integer> mapaAux = new HashMap<String, Integer>();
        Random r = new Random();

        for (String p: this.setDePalavras
             ) {
            mapaAux.put(p, r.nextInt(10));
        }


        return mapaAux;


    }

    public void gravarMapaDePalavras(Path destinoPath){




            try{

                for(Map.Entry<String, Integer> entry : this.mapaPalavras.entrySet()) {
                    Files.write(destinoPath, Collections.singleton((entry.getKey() + " ; " + entry.getValue())),
                            StandardOpenOption.CREATE,
                            StandardOpenOption.APPEND,
                            StandardOpenOption.WRITE);
                }


            } catch (IOException e) {
                System.out.println( "Erro ao Escrever!" );
            }




    }










}

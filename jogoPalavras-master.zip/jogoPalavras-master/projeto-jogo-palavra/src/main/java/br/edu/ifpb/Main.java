package br.edu.ifpb;

import java.nio.file.Paths;
import java.util.Set;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) {




        JogoPalavrasCruzadas jogo = new JogoPalavrasCruzadas(Paths.get("/home/gabriel/Documentos/palavras.txt"));
        jogo.gravarMapaDePalavras(Paths.get("/home/gabriel/Documentos/palavrasGravadas.txt"));


        System.out.println(jogo.getMelhorPalavra());
        System.out.println(jogo.getPalavrasPorFaixaPontos(4,5));





    }

}

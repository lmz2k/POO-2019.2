package br.edu.ifpb;

public class emptyEntryExeption extends Throwable{

    public emptyEntryExeption(){
        this("Entrada vazia!");
    }

    public emptyEntryExeption(String mensagem){
        super(mensagem);
    }



}

package br.edu.ifpb;


import org.apache.commons.lang3.StringUtils;

public class App {
    public static void main(String[] args) {
        double Soma = 0;
        for (String entrada : args) {
            try {


                if (Double.parseDouble(entrada) > 0) Soma += Double.parseDouble(entrada);
                else throw new emptyEntryExeption();

            } catch (NumberFormatException e) {
                System.out.println("Ignorado = " + entrada);
            } catch (emptyEntryExeption ignored) {
                System.out.println("Ignorado = " + entrada);
            }



        }

        System.out.println(Soma);
    }
}
package com.gmail.gabriel1997lima;

public class MangaTipo2 extends Manga {


    public MangaTipo2() {
        super();
    }

    public MangaTipo2(String c, String t, int u) {
        super(c, t, u);
    }

    @Override
    public boolean alterarUnidade() {
        return super.alterarUnidade();
    }

    @Override
    public String getCodigo() {
        return super.getCodigo();
    }

    @Override
    public void setCodigo(String codigo) {
        super.setCodigo(codigo);
    }

    @Override
    public String getTitulo() {
        return super.getTitulo();
    }

    @Override
    public void setTitulo(String titulo) {
        super.setTitulo(titulo);
    }

    @Override
    public int getUnidades() {
        return super.getUnidades();
    }

    @Override
    public void setUnidades(int unidades) {
        super.setUnidades(unidades);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}

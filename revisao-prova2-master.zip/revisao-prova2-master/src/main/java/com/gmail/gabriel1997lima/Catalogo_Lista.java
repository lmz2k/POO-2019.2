package com.gmail.gabriel1997lima;


import java.util.ArrayList;
import java.util.List;

public class Catalogo_Lista  implements Catalogo {

    List<Manga> lista = new ArrayList<>();



    @Override
    public boolean addManga(Manga m) {

        for (Manga aux: lista) {
            if( aux == m){
                return false;
            }
        }
        lista.add(m);
        return true;

    }

    @Override
    public boolean removerManga(String codigo) {
        for (Manga aux: lista) {
            if( aux.getCodigo().equals(codigo)){
                lista.remove(aux);
            }
        }

        return false;
    }

    @Override
    public boolean comprarManga(String codigo) {

        for (Manga aux: lista) {
            if( aux.getCodigo() == codigo && aux.getUnidades() > 0){
                aux.alterarUnidade();
                return true;
            }
        }

        return false;
    }

    @Override
    public void mostrarCatalogo() {

        for (Manga aux: lista) {
            System.out.println(aux.toString());
            }
        }



    }



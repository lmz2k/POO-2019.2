package com.gmail.gabriel1997lima;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Catalogo_Set implements Catalogo{


    Set<Manga> catalogo_set = new HashSet<>();


    @Override
    public boolean addManga(Manga m) {

        if (catalogo_set.contains(m)) return false;
        return catalogo_set.add(m);

    }

    @Override
    public boolean removerManga(String codigo) {

        for (Manga m : catalogo_set) {
            if (m.getCodigo().equals(codigo)) return catalogo_set.remove(m);

        }
        return false;
    }

    @Override
    public boolean comprarManga(String codigo) {
        for (Manga m : catalogo_set) {
            if (m.getCodigo().equals(codigo)){
                m.alterarUnidade();
                return true;
            }

        }
        return false;
    }

    @Override
    public void mostrarCatalogo() {


        for (Manga m: catalogo_set){
            System.out.println(m.toString());

        }


    }
}

package com.gmail.gabriel1997lima;

abstract public class Manga {


    private String codigo;
    private String titulo;
    private int unidades;


    public Manga(){

        this("0000", "Sem Titulo", 0);


    }

    public Manga(String c, String t, int u){

        this.setCodigo(c);
        this.setTitulo(t);
        this.setUnidades(u);

    }



    public boolean alterarUnidade(){

        this.setUnidades(this.getUnidades() - 1);
        return true;

    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }


    @Override
    public String toString() {
        return "Manga{" +
                "codigo='" + codigo + '\'' +
                ", titulo='" + titulo + '\'' +
                ", unidades=" + unidades +
                '}';
    }


}







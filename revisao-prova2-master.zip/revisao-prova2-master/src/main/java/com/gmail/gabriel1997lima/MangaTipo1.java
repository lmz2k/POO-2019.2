package com.gmail.gabriel1997lima;

public class MangaTipo1 extends Manga {


    public MangaTipo1() {

        super("000","sem nome", 90);

            }

    public MangaTipo1(String c, String t, int u) {
        super(c, t, u);
    }

    public void abrirPaginaEVoarPorpurina(){
        System.out.println("cahusahusahuashuas");
    }


    @Override
    public boolean alterarUnidade() {
        return super.alterarUnidade();
    }

    @Override
    public String getCodigo() {
        return super.getCodigo();
    }

    @Override
    public void setCodigo(String codigo) {
        super.setCodigo(codigo);
    }

    @Override
    public String getTitulo() {
        return super.getTitulo();
    }

    @Override
    public void setTitulo(String titulo) {
        super.setTitulo(titulo);
    }

    @Override
    public int getUnidades() {
        return super.getUnidades();
    }

    @Override
    public void setUnidades(int unidades) {
        super.setUnidades(unidades);
    }

    @Override
    public String toString() {
        return super.toString();
    }



}

package com.gmail.gabriel1997lima;

import java.util.HashMap;
import java.util.Map;






public class Catalogo_Mapa implements Catalogo {

    Map<String, Manga> mapa_de_mangas = new HashMap<>();



    @Override
    public boolean addManga(Manga m) {

        if(mapa_de_mangas.containsKey(m.getCodigo())) return false;

        mapa_de_mangas.put(m.getCodigo(), m);
        return true;



    }

    @Override
    public boolean removerManga(String codigo) {

        if(mapa_de_mangas.containsKey(codigo)){
            mapa_de_mangas.remove(codigo);
            return true;
        }
        return false;
    }

    @Override
    public boolean comprarManga(String codigo) {
        if(mapa_de_mangas.containsKey(codigo)){

            mapa_de_mangas.get(codigo).alterarUnidade();
            return true;
        }
        return false;
    }

    @Override
    public void mostrarCatalogo() {

        System.out.println(mapa_de_mangas.toString());

        for (String keys : mapa_de_mangas.keySet())
        {
            System.out.println(mapa_de_mangas.get(keys));
        }



    }
}

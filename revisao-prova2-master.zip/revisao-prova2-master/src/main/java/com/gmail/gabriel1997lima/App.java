package com.gmail.gabriel1997lima;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
//        Catalogo cat = new Catalogo_Lista();
//        Catalogo cat = new Catalogo_Mapa();

        Catalogo cat = new Catalogo_Set();
        Manga a = new MangaTipo1();
        Manga b = new MangaTipo1("001","saduas",10);
        cat.addManga(a);
        cat.addManga(b);
        cat.mostrarCatalogo();

        cat.comprarManga("001");
        cat.mostrarCatalogo();
    }

}

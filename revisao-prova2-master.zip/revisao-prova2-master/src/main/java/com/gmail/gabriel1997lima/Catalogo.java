package com.gmail.gabriel1997lima;

public interface Catalogo {


    boolean addManga(Manga m);
    boolean removerManga(String codigo);
    boolean comprarManga(String codigo);
    void mostrarCatalogo();



}






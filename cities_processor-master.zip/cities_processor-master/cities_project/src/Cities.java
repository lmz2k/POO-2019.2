import java.util.Objects;

public class Cities implements Comparable<Cities>{

    private String Nome;
    private String Estado;
    private String ZipCode;





    public Cities(String N, String E, String H){
        this.setNome(N);
        this.setEstado(E);
        this.setZipCode(H);

    }





    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        this.Nome = nome;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String estado) {
        this.Estado = estado;
    }

    public String getZipCode() {
        return ZipCode;
    }

    public void setZipCode(String zipCode) {
        ZipCode = zipCode;

    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getNome());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (!(obj instanceof Cities) || obj == null) return false;

        Cities other = (Cities) obj;
        if (this.getNome().equals(other.getNome())){
            return true;
        }
        return false;


    }

    @Override
    public int compareTo(Cities outra){
        return getNome().compareTo(outra.getNome());
    }

}

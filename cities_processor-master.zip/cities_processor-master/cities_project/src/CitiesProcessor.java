import javax.sound.midi.Patch;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class CitiesProcessor {



    private Set<Cities> citiesSet = new TreeSet<>();



    public Set<Cities> getCitiesSet() {
        return citiesSet;
    }

    public void setCitiesSet(Set<Cities> citiesSet) {
        this.citiesSet = citiesSet;
    }


    public Set<Cities> buildSetOfCities(Path filePath){

        Set<Cities> setAux = new TreeSet<>();

        try(FileReader fr = new FileReader(String.valueOf(filePath));
            BufferedReader br = new BufferedReader( fr );) {

            String linha;

            while ( ( linha = br.readLine() ) != null )
            {
                String[] palavras = linha.split(",");
                String Nome = palavras[0];
                String Estado = palavras[1];
                String zipCode = palavras[2];
                Cities city = new Cities(Nome, Estado, zipCode);

                setAux.add(city);

            }

        } catch ( FileNotFoundException e ) {
            System.out.println( "Erro: arquivo não existe." );
        }catch (IOException e) {
            System.out.println( "Erro na varredura do arquivo." );
        }

        return setAux;
    }

    public void writeSetOfCities(Path destino, Comparator<Cities> comparator){


        Set<Cities> setOrdenado = new TreeSet<>(comparator);
        setOrdenado.addAll(getCitiesSet());

        setOrdenado.forEach(cities -> {

            try{
                Files.write( destino,
                        Collections.singleton(String.format(cities.getNome() + "," +cities.getEstado() + "," +cities.getNome() + "," +cities.getZipCode())),
                        StandardOpenOption.CREATE, 
                        StandardOpenOption.APPEND,
                        StandardOpenOption.WRITE );
            } catch (IOException e) {
                System.out.println("Erro ao escrever arquivo!");;
            }

        });


    }

    public void print(){
        this.getCitiesSet().forEach(cities -> {
            System.out.println(cities.getNome() + "," +cities.getEstado() + "," +cities.getNome() + "," +cities.getZipCode());
        });
    }



}

import java.util.Comparator;

public class ComparatorByState implements Comparator<Cities> {

    @Override
    public int compare(Cities cities, Cities t1) {
        return cities.getEstado().compareTo(t1.getEstado());
    }
}

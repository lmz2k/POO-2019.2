import java.nio.file.Path;
import java.util.Comparator;
import java.util.Set;

public class CitiesProcessorDemo {



    public static void main(String[] args) {


        CitiesProcessor cp = new CitiesProcessor();

        Set<Cities> set = cp.buildSetOfCities(Path.of("/home/gabriel/cities.txt"));
        cp.setCitiesSet(set);

        ComparatorByZipCode comparatorByZipCode = new ComparatorByZipCode();
        ComparatorByState comparatorByState = new ComparatorByState();

        cp.writeSetOfCities(Path.of("/home/gabriel/cities_default.txt"), Comparator.naturalOrder());
        cp.writeSetOfCities(Path.of("/home/gabriel/cities_byZip.txt"), comparatorByState);
        cp.writeSetOfCities(Path.of("/home/gabriel/cities_byState.txt"), comparatorByZipCode);




    }


}

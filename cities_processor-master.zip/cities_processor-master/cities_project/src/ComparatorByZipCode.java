import java.util.Comparator;

public class ComparatorByZipCode implements Comparator<Cities> {

    @Override
    public int compare(Cities cities, Cities t1) {
        return  cities.getZipCode().compareTo(t1.getZipCode());
    }


}
